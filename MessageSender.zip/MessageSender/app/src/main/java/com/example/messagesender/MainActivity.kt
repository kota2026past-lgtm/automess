package com.example.messagesender

import android.Manifest
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.telephony.SmsManager
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Button
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.core.content.edit
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent { AppTheme { SenderScreen() } }
    }
}

// ---------- Local storage ----------

data class HistoryItem(
    val phone: String,
    val message: String,
    val whatsApp: Boolean,
    val time: Long
)

class Store(context: Context) {
    private val prefs = context.getSharedPreferences("sender", Context.MODE_PRIVATE)

    var phone: String
        get() = prefs.getString("phone", "") ?: ""
        set(v) = prefs.edit { putString("phone", v) }

    var message: String
        get() = prefs.getString("message", "") ?: ""
        set(v) = prefs.edit { putString("message", v) }

    var useWhatsApp: Boolean
        get() = prefs.getBoolean("useWhatsApp", true)
        set(v) = prefs.edit { putBoolean("useWhatsApp", v) }

    fun history(): List<HistoryItem> = try {
        val arr = JSONArray(prefs.getString("history", "[]") ?: "[]")
        (0 until arr.length()).map {
            val o = arr.getJSONObject(it)
            HistoryItem(
                o.getString("phone"),
                o.getString("message"),
                o.getBoolean("wa"),
                o.getLong("time")
            )
        }
    } catch (e: Exception) {
        emptyList()
    }

    fun addHistory(item: HistoryItem) {
        val list = (listOf(item) + history()).take(20)
        val arr = JSONArray()
        list.forEach {
            arr.put(
                JSONObject()
                    .put("phone", it.phone)
                    .put("message", it.message)
                    .put("wa", it.whatsApp)
                    .put("time", it.time)
            )
        }
        prefs.edit { putString("history", arr.toString()) }
    }

    fun clearHistory() = prefs.edit { remove("history") }
}

// ---------- UI ----------

private val Green = Color(0xFF128C7E)

@Composable
fun AppTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = lightColorScheme(primary = Green, onPrimary = Color.White),
        content = content
    )
}

@Composable
fun SenderScreen() {
    val context = LocalContext.current
    val store = remember { Store(context) }

    var phone by remember { mutableStateOf(store.phone) }
    var message by remember { mutableStateOf(store.message) }
    var useWhatsApp by remember { mutableStateOf(store.useWhatsApp) }
    var history by remember { mutableStateOf(store.history()) }

    fun toast(text: String) = Toast.makeText(context, text, Toast.LENGTH_SHORT).show()

    fun send() {
        val ok = if (useWhatsApp) sendWhatsApp(context, phone, message)
        else sendSms(context, phone, message)
        if (ok) {
            store.addHistory(
                HistoryItem(phone.trim(), message, useWhatsApp, System.currentTimeMillis())
            )
            history = store.history()
        }
    }

    val smsPermission = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) send() else toast("SMS permission denied")
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .systemBarsPadding()
            .imePadding()
            .padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text(
            "Message Sender",
            style = MaterialTheme.typography.headlineSmall,
            fontWeight = FontWeight.Bold,
            color = Green
        )

        OutlinedTextField(
            value = phone,
            onValueChange = { phone = it; store.phone = it },
            label = { Text("Number with country code, e.g. 919876543210") },
            singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
            modifier = Modifier.fillMaxWidth()
        )

        OutlinedTextField(
            value = message,
            onValueChange = { message = it; store.message = it },
            label = { Text("Message") },
            minLines = 3,
            maxLines = 6,
            modifier = Modifier.fillMaxWidth()
        )

        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("SMS")
            Switch(
                checked = useWhatsApp,
                onCheckedChange = { useWhatsApp = it; store.useWhatsApp = it },
                modifier = Modifier.padding(horizontal = 12.dp)
            )
            Text("WhatsApp")
        }

        Button(
            onClick = {
                val digits = phone.filter { it.isDigit() }
                when {
                    digits.length !in 7..15 -> toast("Enter a valid number with country code")
                    message.isBlank() -> toast("Type a message first")
                    useWhatsApp -> send()
                    ContextCompat.checkSelfPermission(
                        context, Manifest.permission.SEND_SMS
                    ) == PackageManager.PERMISSION_GRANTED -> send()
                    else -> smsPermission.launch(Manifest.permission.SEND_SMS)
                }
            },
            modifier = Modifier.fillMaxWidth()
        ) { Text("Send") }

        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text("Recent", style = MaterialTheme.typography.titleMedium)
            if (history.isNotEmpty()) {
                TextButton(onClick = { store.clearHistory(); history = emptyList() }) {
                    Text("Clear")
                }
            }
        }

        LazyColumn(modifier = Modifier.weight(1f)) {
            items(history) { item ->
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable {
                            phone = item.phone
                            message = item.message
                            useWhatsApp = item.whatsApp
                            store.phone = item.phone
                            store.message = item.message
                            store.useWhatsApp = item.whatsApp
                        }
                        .padding(vertical = 8.dp)
                ) {
                    Text(
                        "${if (item.whatsApp) "WhatsApp" else "SMS"} · ${item.phone}",
                        fontWeight = FontWeight.Medium
                    )
                    Text(
                        item.message,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis,
                        style = MaterialTheme.typography.bodyMedium
                    )
                    Text(
                        SimpleDateFormat("dd MMM, HH:mm", Locale.getDefault()).format(Date(item.time)),
                        style = MaterialTheme.typography.labelSmall
                    )
                }
                HorizontalDivider()
            }
        }
    }
}

// ---------- Sending ----------

@Suppress("DEPRECATION")
fun sendSms(context: Context, phone: String, message: String): Boolean = try {
    val sms = (if (Build.VERSION.SDK_INT >= 31)
        context.getSystemService(SmsManager::class.java)
    else SmsManager.getDefault()) ?: error("SMS not supported on this device")
    val number = phone.trim().filter { it.isDigit() || it == '+' }
    sms.sendMultipartTextMessage(number, null, sms.divideMessage(message), null, null)
    Toast.makeText(context, "SMS sent to the network", Toast.LENGTH_SHORT).show()
    true
} catch (e: Exception) {
    Toast.makeText(context, "SMS failed: ${e.message}", Toast.LENGTH_LONG).show()
    false
}

fun sendWhatsApp(context: Context, phone: String, message: String): Boolean {
    // wa.me needs digits only, with country code, no "+" or spaces
    val digits = phone.filter { it.isDigit() }
    val uri = Uri.parse("https://wa.me/$digits?text=${Uri.encode(message)}")
    // Try WhatsApp, then WhatsApp Business, then fall back to the browser
    for (pkg in listOf("com.whatsapp", "com.whatsapp.w4b", null)) {
        try {
            val intent = Intent(Intent.ACTION_VIEW, uri)
            if (pkg != null) intent.setPackage(pkg)
            context.startActivity(intent)
            return true
        } catch (_: ActivityNotFoundException) {
        }
    }
    Toast.makeText(context, "Could not open WhatsApp", Toast.LENGTH_SHORT).show()
    return false
}
