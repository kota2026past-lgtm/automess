# Message Sender

Enter a mobile number and a message, then tap Send. SMS opens your Messages app and
WhatsApp opens the chat, both prefilled; tap Send there. No permissions are needed.
The last draft and the last 20 sent messages are saved on the device (tap one to resend).

Build: push to GitHub -> Actions tab -> "Build APK" -> download the `MessageSender-apk` artifact.
