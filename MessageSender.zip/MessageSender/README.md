# Message Sender

Android app: enter a mobile number and a message, then send it by SMS (automatic)
or WhatsApp (opens the chat prefilled; tap WhatsApp's Send). The last draft and the
last 20 sent messages are saved on the device.

Build: push to GitHub -> Actions tab -> "Build APK" -> download the `MessageSender-apk` artifact.
